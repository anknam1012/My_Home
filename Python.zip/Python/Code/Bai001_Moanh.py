import cv2 as cv
import numpy as np
# imread : đọc hình ảnh
img= cv.imread("D:\\Nam_EPU\\Nam_FSI\\Python\\Code\\AnhRonaldo.jpg",1)
#namewindow tạo cửa sổ tên image đẻ hiện thị hình ảnh
#cv.namedWindow('image', cv.WINDOW_NORMAL)
# imshow : hiện thị hình ảnh 
cv.imshow("Ronaldo",img)
#cv.imwrite('abc.jpg',img)
# waitkey(0): nhấn phím 0 để kết thúc 
cv.waitKey(0)
# giải phóng bộ nhớ bản chụp
cv.destroyAllWindows()