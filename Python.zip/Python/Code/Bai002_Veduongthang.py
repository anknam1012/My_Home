import numpy as np 
import cv2
# imread(): đọc ảnh 
img = cv2.imread("AnhRonaldo.jpg",1)
# cv.line(ảnh, điểm 1, điểm 2, màu, độ pixel)
cv2.line(img,(0,0), (150,150), (0,0,0),2)
# cv.imwrite() : viết ảnh 
cv2.imwrite("AnhRonaldo1.jpg",img)
# cv.imshow(): Lưu ảnh 
cv2.imshow("Ronaldo1",img)
cv2.waitKey(0)
# cv.destroyAllWindows(): giải phóng bộ nhớ 
cv2.destroyAllWindows()