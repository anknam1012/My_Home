import cv2

img1=cv2.imread("AnhKyYeu.jpg", 1)
img2=cv2.imread("AnhClass.jpg", 1)

# Cắt ảnh 
img1 = img1[300: 500, 400: 600]
img2 = img2[300: 500, 400: 600]

# trộn ảnh
img3=cv2.add(img1 , img2)
# imshow (): Mở ảnh 
cv2.imshow("image3",img3)

cv2.waitKey(0)
cv2.destroyAllWindows()