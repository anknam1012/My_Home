import cv2
import numpy as np 
img = cv2.imread("AnhVeDuongThang.jpg",1)
# cv2.imshow("tru cap tung phan ",img)
#cv2.waitKey(0)
#cv2.destroyAllWindows() 

px=img[0][0]
print (px)

#sua o vi tri 0,0
img[0][0]=[1,1,1]
for i in range(100):
    img[i][i]=[1,1,1]
    img[i+2][i+2]=[1,1,1]
cv2.imwrite("AnhVeDuongThang.jpg",img)
