import cv2
import numpy as np 

img=cv2.imread("AnhKyYeu.jpg",-1)
#kích thước của ảnh
print (img.shape)
# xem  ảnh là bao nhiêu bit
print (img.dtype)
# chiều rộng của ảnh
print (img.size)
#=====Hàm liên quan đến cắt ảnh=========
# subimg :ảnh con
#[200:300] từ 200 đến 300
subimg =img[200:1000,400:1000]
 # chuyển kênh màu
subimg=subimg[:,:,0]
cv2.imshow("image",subimg)
cv2.waitKey(0)
cv2.destroyAllWindows()
