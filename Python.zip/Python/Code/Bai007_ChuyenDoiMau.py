import cv2
import numpy as np 

# tham số ngược lại 
img1 =np.uint8([[[36,28,237]]])
# CVTCOLOR :chuyển không gian mầu)
hsv1=cv2.cvtColor(img1,cv2.COLOR_BGR2HSV)
print (hsv1)

img2=cv2.imread("AnhOpencv.png",1)
hsv2=cv2.cvtColor(img2,cv2.COLOR_BGR2HSV)
cv2.imshow("image",hsv2)
cv2.waitKey(0)
cv2.destroyAllWindows()