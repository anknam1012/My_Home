import cv2 as cv 
import numpy as np 
from matplotlib import pyplot as plt 
# tìm biểu đồ:
img = cv.imread("AnhkyYeu.jpg", 0)
plt.hist(img.ravel(), [256], [0,256])
plt.show()