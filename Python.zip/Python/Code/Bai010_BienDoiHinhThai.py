
import numpy as np 
from matplotlib import pyplot as plt 
img = cv.imread('AnhChuJ.png', 0 )
'''img = cv.imread('AnhChuJ1.png', 0 )
img = cv.imread('AnhChuJ2.png', 0 )'''
kernel =np.ones((5,5), np.uint8)
# Erosion : xói mòn 
#erosion = cv.erode(img, kernel, iterations=1)
# dilation : sự giãn nở 
#dilation = cv.dilate(img, kernel, iterations= 1)
# opening : mở đầu 
# hàm morphologyEx: thực hiện sự biến đổi
#opeing  = cv.morphologyEx(img, cv.MORPH_OPEN, kernel)
# closing : kết thúc
#closing = cv.morphologyEx(img, cv.MORPH_CLOSE, kernel)
# gradient hình thái:
#gradient = cv.morphologyEx (img, cv.MORPH_GRADIENT, kernel)
# top hat: mũ lưỡi trai
#tophat = cv.morphologyEx(img, cv.MORPH_TOPHAT, kernel)
blackhat = cv.morphologyEx(img, cv.MORPH_BLACKHAT, kernel)
#cv.imshow(" frist ",img)
#cv.imshow(" erosion ", erosion)
#cv.imshow(" dilation ", dilation)
#cv.imshow(" opeing ", opeing)
#cv.imshow(" closing ", closing)
#cv.imshow(" gradient ", gradient)
#cv.imshow(" tophat ", tophat)
cv.imshow("blackhat",blackhat)
cv.waitKey(0)
cv.destroyAllWindows()