import numpy as np
import cv2 as cv
img = cv.imread('AnhKyYeu.jpg')
# fx :hs tỷ lệ theo chiều ngang,fy: hệ số tỷ lệ theo chiều dọc
#cv.INTER_CUBIC:phép nội suy 2 chiều trên vùng lân cận 4*4 pixel 
res = cv.resize(img,None,fx=2, fy=2, interpolation = cv.INTER_CUBIC)
cv.imshow(" ",res)
cv.waitKey(0)
cv.destroyAllWindows()
#OR
#height, width = img.shape[:2]
#res = cv.resize(img,(2*width, 2*height), interpolation = cv.INTER_CUBIC)
