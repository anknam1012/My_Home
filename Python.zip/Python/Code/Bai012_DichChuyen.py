import numpy as np
import cv2 as cv
img = cv.imread('AnhkyYeu.jpg',0)
rows,cols = img.shape
M = np.float32([[1,0,100],[0,1,50]])
#(cols,rows): kích thước của ảnh đầu ra 
#M : 2x3 ma trận biến đổi,đầu vào
#dst : kết quả đầu ra 
#cols: số cột ;rows: số hàng 
dst = cv.warpAffine(img,M,(cols,rows))
cv.imshow('img',dst)
cv.waitKey(0)
cv.destroyAllWindows()