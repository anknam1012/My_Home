import cv2 as cv
import numpy as np 
from matplotlib import pyplot as plt
img = cv.imread('AnhRonaldo.jpg',0)
rows,cols = img.shape
# tọa độ các đỉnh tam giác trong ảnh nguồn 
# tọa đọ các đỉnh tam giác tương đương ở ảnh đích
pts1 = np.float32([[50,50],[200,50],[50,200]])
pts2 = np.float32([[10,100],[200,50],[100,250]])
# M : biến đổi sau khi có được 
M = cv.getAffineTransform(pts1,pts2)
dst = cv.warpAffine(img,M,(cols,rows))
# title : tiêu đề 
# subplot : phân nhóm hay âm mưu phụ
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()