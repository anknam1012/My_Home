import numpy as np
import cv2
from matplotlib import pyplot as plt

img = cv2.imread("AnhChuNhanDang.png",0)
'''cv2.imshow("abc",img)'''

cells = [np.hsplit(row, 100) for row in np.vsplit(img, 50)]
cv2.imwrite('anh_so.jpg',cells[0][0])
print (cells[0][0])

'''cv2.waitKey(0)
cv2.destroyAllWindows()'''