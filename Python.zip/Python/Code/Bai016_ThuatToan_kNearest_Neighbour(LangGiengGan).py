import numpy as np 
import cv2
import matplotlib.pyplot as plt

traindata=np.random.randint(0, 100,(25,2)).astype(np.float32)
kq=np.random.randint(0, 2,(25,1)).astype(np.float32)
new=np.random.randint(0, 50,(1,2)).astype(np.float32)
#in ra gia tri mau do
red=traindata[kq.ravel()==1]
plt.scatter(red[:,0],red[:,1],100,'r','s')
blue=traindata[kq.ravel()==0]
plt.scatter(blue[:,0],blue[:,1],100,'b','^')
plt.scatter(new[:,0],new[:,1],100,'g','o')
#ml : mearching learnning
knn= cv2.ml.KNearest_create()
knn.train(traindata,0,kq)
results=knn.findNearest(new,3)
print(results)
plt.show()