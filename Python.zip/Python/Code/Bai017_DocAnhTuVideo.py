import cv2

vidcap = cv2.VideoCapture('AclipTinhBan.mp4')
success, image = vidcap.read()
count = 0
success = True
while success:
    cv2.imwrite("frame%d.jpg" % count , image)
    success,image =vidcap.read()
    print (success)
    count +=1