import cv2 as cv
import numpy as np

img1 = cv.imread('AnhSauKyYeu.png')
img2 = cv.imread('AnhOpencv.png')
# tôi muốn đặt logo phía bên trái của hình ảnh, vì vậy cần tạo ra roi
rows,cols,channels = img2.shape
roi = img1[0:rows, 0:cols ]
# Now create a mask of logo and create its inverse mask also
img2gray = cv.cvtColor(img2,cv.COLOR_BGR2GRAY)
# img2gray :là ảnh xám; 10: giá trị ngưỡng ;255: gia trị được gán nếu pixel lớn hơn giá trị ngưỡng;THRESH_BINARY:nếu giá trị pixel lớn hơn giá trị ngưỡng thì gán bằng maxval
ret, mask = cv.threshold(img2gray, 10, 255, cv.THRESH_BINARY)
# bitwise_not : đảo ngược tất cả các bit
mask_inv = cv.bitwise_not(mask)
# bôi đen khu vực logo trong Roi
#bitwise_and : đúng nếu cả hai cùng đúng 
img1_bg = cv.bitwise_and(roi,roi,mask = mask_inv)
# chỉ lấy vùng logo từ hình ảnh logo 
img2_fg = cv.bitwise_and(img2,img2,mask = mask)
# đặt logo vào roi và sửa đổi hifh ảnh chính
dst = cv.add(img1_bg,img2_fg)
img1[0:rows, 0:cols ] = dst
cv.imshow('res',img1)
cv.waitKey(0)
cv.destroyAllWindows()