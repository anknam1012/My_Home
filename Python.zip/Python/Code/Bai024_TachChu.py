import numpy as np
import cv2 as cv

img_value= np.uint8([[[143,49,43]]])# 118, 178, 143
hsv_img =cv.cvtColor(img_value, cv.COLOR_BGR2HSV)
print (hsv_img)

img2 = cv.imread("Anh2.jpg",1)
hsv_img2 =cv.cvtColor(img2, cv.COLOR_BGR2HSV)

min_text= np.array([50, 100, 100])
max_text= np.array([200, 200, 200])
mask= cv.inRange(hsv_img2, min_text, max_text)

final1= cv.bitwise_and(img2, img2, mask=mask)
gray =cv.cvtColor(final1, cv.COLOR_BGR2GRAY)
cv.imshow("Img", gray)
cv.waitKey(0)