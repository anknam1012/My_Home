import numpy as np 
import cv2 as cv
from matplotlib import pyplot as plt
img=cv.imread('AnhKyYeu.jpg',1)
plt.imshow(img, cmap= 'gray', interpolation= 'bicubic')
# để ẩn các giá trị đánh dấu rên trục x và y 
plt.xticks([]),plt.yticks([])
plt.show()