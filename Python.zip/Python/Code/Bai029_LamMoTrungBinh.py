import cv2 as cv
import numpy as np 
from matplotlib import pyplot as plt

img = cv.imread('AnhKyYeu.jpg')
# blur : phép lọc ảnh làm cho trơn ảnh và khử nhiễu hạt 
#blur = cv.blur(img,(5,5))
# làm mờ theo Gaussian:
#blur = cv.GaussianBlur(img,(5,5), 0)
#làm mờ trung bình:
blur = cv.medianBlur(img,5)
plt.subplot(121),plt.imshow(img),plt.title('Original')
# xticks([]): vô hiệu hóa sticks
# xticks ,yticks : đánh dấu vị trí cho cho trục x và y tương ứng 
plt.xticks([]), plt.yticks([])
plt.subplot(122),plt.imshow(blur),plt.title('Blurred')
plt.xticks([]), plt.yticks([])
plt.show()