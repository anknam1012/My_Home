import cv2 as cv 
import numpy as np 

# Tạo một hình ảnh màu đen
img = np.zeros ((0,0,0), np.uint8)
cv.imshow("image", img)