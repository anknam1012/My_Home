import cv2
import numpy as np
import os
from random import randint

file_paths = []
label_id=0
for folder, subfolders, filenames in os.walk('D:\\Nam_19.02.2020\\KQ_19_02'):
    for filename in filenames:
        if filename.lower().endswith(('.jpg')) or filename.lower().endswith(('.jpeg')) or filename.lower().endswith(('.png')) or filename.lower().endswith(('.bmp')):
            file_paths.append(os.path.join(folder, filename))
with open('./BSX1902.txt','w') as f:
    for fileFullname in file_paths:
        f.write(str(fileFullname))
        f.write('\n')

